from django.db import models

# Create your models here.

class Zvire(models.Model):
    name = models.CharField(max_length=100) # strings
    color = models.CharField(max_length=70) # string
    weight = models.IntegerField(null = True, blank = True) # intg
    description = models.TextField(null = True, blank = True)

    def __str__(self):
        return f"I`m a {self.name} and i`ve color {self.color}"
