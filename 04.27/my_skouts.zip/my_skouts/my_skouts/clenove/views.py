from django.shortcuts import render

from .models import Skaut
# Create your views here.

def uvod(request):
    return render(request,'clenove/uvod.html')

def clenove(request):
    skauti = Skaut.objects.all()
    context = { 'skauti': skauti }
    return render(request,'clenove/clenove.html', context)

def clen_detail(request,cislo):
    skaut_vysledek = Skaut.objects.get(pk=cislo)
    return render(request,'clenove/clen_detail.html',{'skaut_sablon':skaut_vysledek})

