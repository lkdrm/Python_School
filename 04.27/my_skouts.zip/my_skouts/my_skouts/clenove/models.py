from tabnanny import verbose
from django.db import models

# Create your models here.

class Skaut(models.Model):
    name = models.CharField("jmeno",max_length=100)
    prezdivka = models.CharField(verbose_name='Přezdívka',max_length=100,
    help_text='Prosím zadavejte bez diakritiky')
    year = models.IntegerField('Věk')
    splneno = models.BooleanField('splněno',default=False)

    def __str__(self):
        return f'{self.name} - {self.prezdivka}'

    class Meta:
        verbose_name_plural = "Skauti"