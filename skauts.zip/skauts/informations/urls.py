from django.urls import path
from .import views

urlpatterns = [
    path('',views.index, name='index'),
    path('mike', views.mike),
    path('fred', views.fred),
    path('informations/<skaut>',views.informations, name='skouts')
]
