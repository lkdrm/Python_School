from django.db import models

# Create your models here.

class Skout(models.Model):
    name = models.CharField(max_length=100)
    year = models.IntegerField(blank=True)
    another_name = models.CharField(max_length=100)
    description = models.TextField(blank=True)