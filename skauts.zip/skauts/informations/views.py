from django.shortcuts import render
from django.http import Http404
from matplotlib.style import context
# Create your views here.

our_skouts = {
    'Djon':['Like to play with kids','Always created very funny games',],
    'Alexa':'Very smart girl, which know what kids whant',
    'Kile':'One of the best teamleaders which you ever saw',
    'Kartman':'Can make our travelling happy',
}

def index(request):
    context = {"skouts":our_skouts.keys()}
    return render(request,'informations\index.html',context)


def fred(request):
    context = {
        "name":'Fred',
        'year': 30,
        'sex': 'man',
        'hobby': 'play on guitar',
    }
    return render(request,'informations\\fred.html',context)

def mike(request):
    context = {
        'name':'Mike',
        'year': 40,
        'sex':'man',
        'hobby': ['sing a songs','ride on cartings']
    }
    return render(request,'informations\mike.html',context)

def informations(request,skaut):
    inform = our_skouts[skaut]
    return render(request,'informations/about.html', {
        'skaut':skaut,
        'information':inform,
    })