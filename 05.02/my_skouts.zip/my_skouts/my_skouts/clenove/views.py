from django.shortcuts import render,get_object_or_404
from django.http import Http404
from .models import Skaut
# Create your views here.

def uvod(request):
    return render(request,'clenove/uvod.html')

def clenove(request):
    skauti = Skaut.objects.all()
    context = { 'skauti': skauti }
    return render(request,'clenove/clenove.html', context)

def clen_detail(request,slug):
    #try:
    #    skaut_vysledek = Skaut.objects.get(pk=cislo)
    #except Skaut.DoesNotExist:
    #    raise Http404("Skaut se zvolenym id neexistuje")
    skaut_vysledek = get_object_or_404(Skaut,slug=slug)
    context = {'skaut_sablon':skaut_vysledek}
    return render(request,'clenove/clen_detail.html',context)

