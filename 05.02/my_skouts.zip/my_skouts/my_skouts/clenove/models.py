from tabnanny import verbose
from django.db import models
from django.urls import reverse
from django.utils.text import slugify

# Create your models here.

class Skaut(models.Model):
    name = models.CharField("jmeno",max_length=100)
    prezdivka = models.CharField(verbose_name='Přezdívka',max_length=100,
    help_text='Prosím zadavejte bez diakritiky')
    year = models.IntegerField('Věk')
    splneno = models.BooleanField('splněno',default=False)
    slug = models.SlugField()

    def get_absolute_url(self):
        return reverse("detail_clena", args=[self.slug])
    
    #def save(self, *args, **kwargs):
    #    self.slug = slugify(self.prezdivka)
    #    super().save(*args, **kwargs)

    def __str__(self):
        return f'{self.name} - {self.prezdivka}'

    class Meta:
        verbose_name_plural = "Skauti"