from django.contrib import admin

# Register your models here.
from .models import Skaut

class SkautAdmin(admin.ModelAdmin):
    #readonly_fields = ["slug"]
    prepopulated_fields = {"slug": ("prezdivka",)}
    list_display = ["name","prezdivka","year","splneno"]
    list_filter = ["splneno","year"]

admin.site.register(Skaut,SkautAdmin)