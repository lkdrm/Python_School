from urllib import response
from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

first_book = {"Creator":"Bernhard Hennen",
             "Books":"Have written 12 books",
             "First_book":"Elven sword",}

list_of_books = ["The Elven","Elfenwinter","Elfenlicht","Elfenlied","Elfenkönigin",]

def index(request):
    return HttpResponse("Hello everyone this is my page about books which i have read.")

def firstBook(request):
    response = f'<h4>My first book which i start to read was:{first_book["First_book"]}'
    response += f'<p>Written by: {first_book["Creator"]}</p>'
    response += f'<p>Consist: {first_book["Books"]}.</p>'
    return HttpResponse(response)

def bernBooks(request):
    string = "<ol>\n"
    for book in list_of_books:
        string += f'<li>{book}</li>'
    string +="</ol>"
    return HttpResponse(f'Almost all books which he have write : {string}' )