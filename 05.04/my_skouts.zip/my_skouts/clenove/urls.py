from . import views
from django.urls import path

urlpatterns = [
    path('', views.uvod, name='uvod'),
    path('clenove', views.clenove, name='clenove'),
    path('clenove/<slug:slug>', views.clen_detail, name='detail_clena'),
    #path("")
]
