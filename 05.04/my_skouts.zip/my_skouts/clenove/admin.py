from django.contrib import admin

# Register your models here.
from .models import Bobrik, Skaut, Oddil, AdresaKlubovny

class SkautAdmin(admin.ModelAdmin):
    #readonly_fields = ["slug"]
    prepopulated_fields = {"slug": ("prezdivka",)}
    list_display = ["name","prezdivka","year","splneno", "oddil"]
    list_filter = ["splneno","year","oddil"]


class OddilAdmin(admin.ModelAdmin):
    list_display = ["jmeno","heslo","seznam_skautu",] 

class AdresaKlubovnyAdmin(admin.ModelAdmin):
    list_display = ["ulice", "cislo_popisne"]

class BobriciAdmin(admin.ModelAdmin):
    list_display = ["nazev","barva"]


admin.site.register(Skaut,SkautAdmin)
admin.site.register(Oddil,OddilAdmin)
admin.site.register(AdresaKlubovny,AdresaKlubovnyAdmin)
admin.site.register(Bobrik,BobriciAdmin)