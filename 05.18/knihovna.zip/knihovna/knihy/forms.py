import imp
from django import forms

from .models import Kniha
"""
class KnihaForm(forms.Form):
    jmeno = forms.CharField(max_length=20, 
                            label="zadej jmeno knihy",
                            label_suffix=":",
                            initial="Zadej to sem",
                            error_messages={
                                "required":"Tohle policko je povinne",
                                "max_length":"Moc dlouhy text, povoleno je maximalne 20 znaku."
                            })
    autor = forms.CharField(max_length=100,label="Jmeno autora")
    recenze = forms.CharField(max_length = 2000, label = "Recenze knihy",
                            widget=forms.Textarea)
"""

class KnihaForm(forms.ModelForm):
    class Meta:
        model = Kniha
        fields = ['jmeno','autor','recenze']
        labels= {'jmeno':"zadej jmeno knihy",
                'autor':"zadej jmeno autora",
                'recenze':"zadej recenze"}
        error_message = {
            "jmeno":{
                    "required":"Tohle policko je povinne",
                    "max_length":"Moc dlouhy text, povoleno je maximalne 20 znaku.",
            }
        }
