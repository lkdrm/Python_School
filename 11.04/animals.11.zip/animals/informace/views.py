from django.shortcuts import render
from django.http import HttpResponse, Http404

nase_zvirata = {
    "krtek": "Krtek žije pod zemí",
    "opice": "Opice mají rády banány",
    "hroch": "Hroch je velký zabiják",
    "pes": "Pes rád štěká",
    "pštros": "Pštros je pták, ale nelétá"
}

# Create your views here.

def index(request):
    context = {"zvirata":nase_zvirata.keys()}
    #response = "<h1>Hlavní stránka o zvířatech.</h1>\n"
    #response += "<p> Metoda je " + request.method + "</p>\n"
    #response += "<ol>\n"
    #for zvire, popis in nase_zvirata.items():
    #    response += f'<li><a href="informace/{zvire}">{zvire}</a> - {popis} </li>\n'
    #response += "</ol>"
    #return HttpResponse(response)
    return render(request,"informace\index.html",context)

def slon(request):
    context = {
        "jmeno":"Jambo-Jumbo",
        "barva":"ruzova",
        "povolani":"Strikat na lidi vodu",
        "je_hezky":True,
    }
    return render(request,"informace\slon.html",context)

def zirafa(request):
    context = {
        "slovo":"nosorozec",
        "text":"hroch je moje oblibene zvire",
        "angl_slovo":"dog",
        "pocet_psu": 3,
        "cislo": 57,
        "jako_string": "58",
        "je_hezky": True,
        "je_hezky_2":False,
        "je_hezky_3":None,
        "seznam": ["pes","kocka","mys",],
        "s1":[1,2,3],
        "s2":[4,5,6],
    }
    return render(request,"informace\zirafa.html",context)




def informace(request, zvire):
    # verze 1:
    #if zvire not in nase_zvirata:
    #    raise Http404(f"Zvíře {zvire} nebylo v naší aplikaci nalezeno.")
    #popis = nase_zvirata[zvire]
    #return HttpResponse(f"<p>Zvíře {zvire} má tento popis: {popis}.</p>")
    # verze 2:
    try:
        popis = nase_zvirata[zvire]
    except:
        raise Http404(f"Zvíře {zvire} nebylo v naší aplikaci nalezeno.")
    return HttpResponse(f"<p>Zvíře {zvire} má tento popis: {popis}.</p>")

# DTL - Django template language