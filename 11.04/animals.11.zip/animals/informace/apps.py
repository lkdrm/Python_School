from django.apps import AppConfig


class InformaceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'informace'
